#include <stdio.h>
#include <malloc.h>

int main(int argc, char** argv) {
	FILE *fp;
	unsigned char header[54];
	unsigned int width, height, width_; 
	int n, x, y;
	unsigned char *bmp;
	
	if (argc < 2) printf("usage: extract <aaa.bmp>\n"); 
	fp = fopen(argv[1], "rb");
	if (!fp) return -1;
	n = fread((void *)header, 1, sizeof(header), fp);
	if (sizeof(header) != n) return -1;
	//printf("hello %d\n", n);
	width = (header[15] << 24) | (header[16]) << 16 | (header[17] << 8) | header[18];
	height = (header[19] << 24) | (header[20] << 16) | (header[21] << 8) | header[22];
	printf("width = %d, height = %d\n", width, height);
	bmp = (unsigned char *)calloc(width * height * 3, 1);
	fread((void *)bmp, width * height * 3, 1, fp);
	printf("pos == %X\n", ftell(fp));
	width_ = 16;
	for (y = height - 1; y >= 0; --y) {
		for (x = 0; x < width; ++x) { //36H->63H=2DH=45=3*15
			unsigned char byte0 = bmp[y * width_ * 3 + x * 3 + 0];
			unsigned char byte1 = bmp[y * width_ * 3 + x * 3 + 1];
			unsigned char byte2 = bmp[y * width_ * 3 + x * 3 + 2];
			unsigned int color = (byte0 << 16) | (byte1 << 8) | byte2;
			//printf("(%06X)", color);
			if (color != 0) {
				printf(" "); //printf("X %X\n", color);
			} else {
				printf(".");
			}
		}
		printf("\n");
	}
	if (fp) fclose(fp);
	return 0;
}
