#include <stdio.h>
#include <malloc.h> /*malloc*/
#include <string.h> /*memcpy*/

#if 0
unsigned char kkk[] = {
0xFF,0xFF,0x1F,0xFF,0x07,0xFF,0x83,0xFF,0xC1,0xFF,0x20,0x7E,0x10,0x3F,0x88,0x1B,
0xC4,0x08,0x62,0x04,0x31,0x82,0x18,0x41,0x8C,0x20,0x46,0x10,0x23,0x80,0x11,0xE0,
0x08,0x7E,0x00,0x7F,0x80,0x7F,0xC0,0xFF,0xE0,0x7F,0xF0,0x3F,0xF8,0x1F,0xFC,0x0F,
0xFE,0x07,0xFF,0x83,0xFF,0xC1,0xFF,0xE0,0x7F,0xF0,0xFF,0xFF,0x00,
};
#endif

int main(int argc, char** argv) {
	unsigned int* outWidth;
	unsigned int* outHeight;
	const char *filename;
	unsigned int width, height;
	unsigned char header[54] = {0};
	unsigned int dataPos;
	unsigned int imageSize;
	unsigned char * data;
	unsigned int zeroByteSize = 0;
	FILE * file;
	int flipY = 1; int flipToBGR = 0;
	int x, y;
	char filename_name[256];
	
	if (argc < 2) 
	{
		fprintf(stderr, "usage: extract <aaa.bmp>\n");
		return -1;
	}
	outWidth = &width;
	outHeight = &height;
	filename = argv[1];
	
	*outWidth = -1;
	*outHeight = -1;
	file = fopen(filename, "rb");
	if (!file)
	{
		fprintf(stderr, "Open input bmp file error\n");
		return -1;
	}
	if (fread(header, 1, sizeof(header), file) != 54)
	{ 
		fprintf(stderr, "Read input bmp file header error\n");
		fclose(file);
		return -1;
	}
	if (header[0] != 'B' || header[1] != 'M')
	{
		fprintf(stderr, "Not a correct BMP file (magic BM)\n");
		fclose(file);
		return -1;
	}
	if (header[24 + 4] != 24 || header[24 + 5] != 0) //biBitCount
	{
		fprintf(stderr, "Not a correct BMP file (24bpp) \n");
		fclose(file);
		return -1;
	}
	dataPos = (header[8 + 2]) | (header[8 + 3] << 8) | (header[8 + 4] << 16) | (header[8 + 5] << 24); //bfOffBits
	imageSize = (header[32 + 2]) | (header[32 + 3] << 8) | (header[32 + 4] << 16) | (header[32 + 5] << 24); //biSizeImage
	*outWidth = (header[16 + 2]) | (header[16 + 3] << 8) | (header[16 + 4] << 16) | (header[16 + 5] << 24); //biWidth
	*outHeight = (header[16 + 6]) | (header[16 + 7] << 8) | (header[16 + 8] << 16) | (header[16 + 9] << 24); //biHeight
	if (imageSize == 0)    
	{
		imageSize = (*outWidth) * (*outHeight) * 3;
	}
	zeroByteSize = (imageSize - (*outWidth) * (*outHeight) * 3) / (*outHeight);
	if (zeroByteSize < 0)
	{
		fprintf(stderr, "zeroByteSize < 0\n");
		fclose(file);
		return -1;
	}
#ifdef _DEBUG
		fprintf(stderr, "[loadBMPRaw][%s]imageSize = %d >= (%d x %d x 3)\n", 
			filename, imageSize, (*outWidth), (*outHeight));
		fprintf(stderr, "[loadBMPRaw][%s]zeroByteSize = %d\n", 
			filename, zeroByteSize);
#endif
	if (dataPos == 0)
	{
		dataPos = 54;
	}
	data = (unsigned char *)malloc(imageSize * sizeof(unsigned char));
	if (data == NULL)
	{
		fprintf(stderr, "Out of memory\n");
		fclose(file);
		return -1;
	}
	//biSizeImage = ((((bi.biWidth * bi.biBitCount) + 31) & ~31) / 8) * bi.biHeight;
	if (zeroByteSize == 0)
	{
		if (imageSize != fread(data, 1, imageSize, file))
		{
			fprintf(stderr, "Read input bmp file data error\n");
			fclose(file);
			return -1;
		}
	}
	else
	{
		unsigned int i;
		unsigned char * p = data;
		for (i = 0; i < *outHeight; i++)
		{
			unsigned int linesize = *outWidth * 3 + zeroByteSize;
			if (linesize != fread(p, 1, linesize, file))
			{
				fprintf(stderr, "Read input bmp file data error\n");
				fclose(file);
				return -1;
			}
			p += *outWidth * 3;
		}
	}
	fclose(file);

	if (flipY)
	{
		unsigned char * tmpBuffer;
		int size;
		unsigned int i;
		size = (*outWidth) * 3;
		tmpBuffer = (unsigned char *)malloc((*outWidth) * 3 * sizeof(unsigned char));
		if (tmpBuffer == NULL)
		{
			fprintf(stderr, "Out of memory\n");
			return -1;
		}
		for (i = 0; i < (*outHeight) / 2; i++)
		{
			memcpy(tmpBuffer, data + (*outWidth) * 3 * i, size);
			memcpy(data + (*outWidth) * 3 * i, data + (*outWidth) * 3 * ( (*outHeight) - i - 1), size);
			memcpy(data + (*outWidth) * 3 * ((*outHeight) - i - 1), tmpBuffer, size);
		}
		free(tmpBuffer);
	}
	if (flipToBGR)
	{
		unsigned int i, j;
		unsigned char * pPixel;
		unsigned char tmpChanel;
		for (i = 0; i < (*outHeight); i++)
		{
			for (j = 0; j < (*outWidth); j++)
			{
				pPixel = data + (*outWidth) * 3 * i + j * 3;
				tmpChanel = *pPixel;
				*pPixel = *(pPixel + 2);
				*(pPixel + 2) = tmpChanel;
			}
		}
	}
	
	if (0) {
		for (y = 0; y < height; ++y) {
			for (x = 0; x < width; ++x) {
				unsigned char byte0 = data[y * width * 3 + x * 3 + 0];
				unsigned char byte1 = data[y * width * 3 + x * 3 + 1];
				unsigned char byte2 = data[y * width * 3 + x * 3 + 2];
				unsigned int color = (byte0 << 16) | (byte1 << 8) | byte2;
				//printf("(%06X)", color);
				if (color != 0) {
					printf(" "); //printf("X %X\n", color);
				} else {
					printf(".");
				}
			}
			printf("\n");
		}
	} else {
		int size = width * height / 8 + 1;
		unsigned char *data2 = (unsigned char *)malloc(size);
		for (x = 0; x < size; ++x) {
			data2[x] = 0;
		}
		for (y = 0; y < height; ++y) {
			for (x = 0; x < width; ++x) {
				unsigned char byte0 = data[y * width * 3 + x * 3 + 0];
				unsigned char byte1 = data[y * width * 3 + x * 3 + 1];
				unsigned char byte2 = data[y * width * 3 + x * 3 + 2];
				unsigned int color = (byte0 << 16) | (byte1 << 8) | byte2;
				if (color != 0) {
					data2[(y * width + x) / 8] |= ((1 << ((y * width + x) % 8)) & 0xff);
				} else {
					data2[(y * width + x) / 8] &= (~(1 << ((y * width + x) % 8)) & 0xff);
				}
			}
		}
		strcpy(filename_name, filename);
		for (x = 0; x < strlen(filename) + 1; ++x) {
			if (filename[x] == '.') {
				filename_name[x] = '_';
			} else {
				filename_name[x] = filename[x];
			}
		}
		printf("unsigned char %s[] = {\n", filename_name);
		for (y = 0; y < size; y += 16) {
			for (x = 0; x < 16 && y + x < size; ++x) { 
				printf("0x%02X,", data2[y + x]);
			}
			printf("\n");
		}
		printf("}\n");
		printf("int %s_width = %d;\n", filename_name, width);
		printf("int %s_height = %d;\n", filename_name, height);
	}
	
	return 0;
}
