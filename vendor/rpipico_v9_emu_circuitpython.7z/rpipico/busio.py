class SPI:
    def try_lock(self):
        return True
    
    def unlock(self):
        pass
    
    def configure(self, baudrate, phase, polarity):
        pass


