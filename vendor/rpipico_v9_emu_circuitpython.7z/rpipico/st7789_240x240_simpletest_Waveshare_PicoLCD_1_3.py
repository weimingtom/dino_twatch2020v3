# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT

"""
This test will initialize the display using displayio and draw a solid green
background, a smaller purple rectangle, and some yellow text.
"""
import board
import busio
import terminalio
import displayio
#from adafruit_display_text import label
from adafruit_st7789 import ST7789
import digitalio
import time

#reset_pin = Pin(0, Pin.OUT)
#reset_pin = digitalio.DigitalInOut(board.GP0)
#reset_pin.direction = digitalio.Direction.OUTPUT

# Release any resources currently in use for the displays
displayio.release_displays()

tft_dc = board.GP1
tft_cs = board.GP15
spi_clk = board.GP2
spi_mosi = board.GP3
tft_rst = board.GP0
backlight = board.GP14
spi = busio.SPI(spi_clk, MOSI=spi_mosi)
while not spi.try_lock():
    pass
#, phase=0, polarity=0
#, phase=True, polarity=True
#, phase=1, polarity=1
spi.configure(baudrate=100000, phase=1, polarity=1)
spi.unlock()

#, reset=tft_rst
display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs, reset=tft_rst)
#, reset=tft_rst



display = ST7789(
    display_bus,
    rotation=0,
    width=240,
    height=240,
    rowstart=0,
    backlight_pin=backlight,
)

print(display)

#reset_pin = digitalio.DigitalInOut(board.GP0)
#reset_pin.direction = digitalio.Direction.OUTPUT
#reset_pin.value = 0

#backlight_pin=backlight,

#while True:
#    pass

#tft_rst.on()



# Make the display context
splash = displayio.Group()
display.show(splash)

color_bitmap = displayio.Bitmap(240, 240, 1)
color_palette = displayio.Palette(1)
color_palette[0] = 0x00FF00  # Bright Green

bg_sprite = displayio.TileGrid(color_bitmap, pixel_shader=color_palette, x=0, y=0)
splash.append(bg_sprite)

# Draw a smaller inner rectangle
inner_bitmap = displayio.Bitmap(200, 200, 1)
inner_palette = displayio.Palette(1)
inner_palette[0] = 0xAA0088  # Purple
inner_sprite = displayio.TileGrid(inner_bitmap, pixel_shader=inner_palette, x=20, y=20)
splash.append(inner_sprite)

# Draw a label
#text_group = displayio.Group(scale=2, x=50, y=120)
#text = "Hello World!"
#text_area = label.Label(terminalio.FONT, text=text, color=0xFFFF00)
#text_group.append(text_area)  # Subgroup for text scaling
#splash.append(text_group)

print("hello")

while True:
    pass
