class TerminalioObj:
    pass
