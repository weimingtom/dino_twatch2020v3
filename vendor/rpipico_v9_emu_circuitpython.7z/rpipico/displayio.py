# https://docs.circuitpython.org/en/latest/shared-bindings/displayio/index.html#displayio.Palette
# Thonny
import uos
import machine
import st7789 as st7789

global g_display


class Palette:
    colorList = []
    size = 0
    
    def __init__(self, size):
        self.size = size
        self.colorList = [None] * self.size
    
    def __getitem__(self, index: int) -> int | None:
        if not self.colorList[index]:
            return 0
        return self.colorList[index]

    def __setitem__(self, index: int, value: int | bytes):
        if type(value) is bytes:
            self.colorList[index] = int.from_bytes(value, 'big') | 0xff000000 # 'little', 'big'
        else:
            self.colorList[index] = value | 0xff000000
        #print("Palette.__setitem__", self.colorList[index])
        
    def make_transparent(self, palette_index: int):
        if self.colorList[palette_index]:
            self.colorList[palette_index] = self.colorList[palette_index] & 0x00ffffff # 'little', 'big'

class Bitmap:
    width = 0
    height = 0
    depth = 0
    #pixels = {}
    pixels = []
    palette: Palette = None
    
    def __init__(self, width, height, depth):
        self.width = width
        self.height = height
        self.depth = depth
        self.pixels = [0] * ((self.width * self.height) // 8 + 1)
        #for index in range(width * height):
        #    self.pixels[index // 8] = 0

    def __getitem__(self, index: Tuple[int, int] | int) -> int:
        if type(index) is not int:
            print("getitem, Bitmap:index:", index)
        return 1 if ((self.pixels[index // 8]) & (1 << (index % 8))) != 0 else 0
    
    def __setitem__(self, index: Tuple[int, int] | int, value: int):
        if type(index) is not int:
            print("setitem, Bitmap:index:", index)
        else:
            pass #print("setitem value:", value)
        if value != 0:
            self.pixels[index // 8] = self.pixels[index // 8] | ((1 << (index % 8)))
        else:
            pass #self.pixels[index // 8] = self.pixels.get(index // 8, 0) & ((~(1 << (index % 8))) & 0xff)

class TileGrid:
    numGridW = 0
    numGridH = 0
    tileWidth = 0
    tileHeight = 0
    x = 0
    y = 0
    default_tile = 0
    hidden = False
    tileMap = None
    tile_id_count = 0
    pixel_shader: Palette = None
    bmp: Bitmap = None
    width: int = 1
    height: int = 1
    tileMap = []
    
    def __init__(self, color_bitmap: Bitmap, pixel_shader: Palette, x: int = 0, y: int = 0, width: int = 1, height: int = 1,
                 tile_width: int | None = None, tile_height: int | None = None, default_tile: int = 0):
        self.bmp = color_bitmap
        self.pixel_shader = pixel_shader
        self.x = x
        self.y = y
        self.width = width if width else 1
        self.height = height if height else 1
        self.tileWidth = tile_width if tile_width else width #???
        self.tileHeight = tile_height if tile_height else height #???
        self.default_tile = default_tile
        self.numGridW = width if width > 0 else 1
        self.numGridH = height if height > 0 else 1
        self.tileMap = [None] * (self.numGridW * self.numGridH)
        for k in range(self.numGridW * self.numGridH):
            self.tileMap[k] = self.default_tile
        
    def __getitem__(self, index: Tuple[int, int] | int) -> int:
        if type(index) is tuple:
            return self.tileMap[index[1] * self.numGridW + index[0]]
        else: #if type(index) is int:
            return self.tileMap[index]
    
    def __setitem__(self, index: Tuple[int, int] | int, value: int):
        if type(index) is tuple:
            self.tileMap[index[1] * self.numGridW + index[0]] = value #print("TileGrid:__setitem__:", index)
        else: #if type(index) is int:
            self.tileMap[index] = value
        
class Group:
    tileGridList = []
    
    def append(self, tileGrid: TileGrid):
        self.tileGridList.append(tileGrid)
        global g_display
        g_display.showAll()

class Display:
    display = None
    groupList = []
    
    def __init__(self, bus: displayio.FourWire, initSquence, **kwargs) -> None:
        st7789_res = 0
        st7789_dc  = 1
        disp_width = 240
        disp_height = 240
        CENTER_Y = int(disp_width/2)
        CENTER_X = int(disp_height/2)
        print(uos.uname())
        spi_sck=machine.Pin(2)
        spi_tx=machine.Pin(3)
        spi0=machine.SPI(0,baudrate=40000000, phase=1, polarity=1, sck=spi_sck, mosi=spi_tx)
        #
        print(spi0)
        self.display = st7789.ST7789(spi0, disp_width, disp_width,
                                  reset=machine.Pin(st7789_res, machine.Pin.OUT),
                                  dc=machine.Pin(st7789_dc, machine.Pin.OUT),
                                  xstart=0, ystart=0, rotation=0)
        self.display.fill(st7789.BLACK)
        global g_display
        g_display = self
    
    def show(self, group: Group):
        self.groupList.append(group)
        print("len(group.tileGridList)", len(group.tileGridList))
        self.showAll()
        
    def showAll(self):
        #self.display.fill(st7789.BLACK)
        #pass
        global g_display
        self.display.fill(st7789.BLACK)
        for group in g_display.groupList:
            for tileGrid in group.tileGridList:
                if tileGrid.hidden:
                    continue
                

                #for y in range(tileGrid.bmp.height):
                #    for x in range(tileGrid.bmp.width):
                #        self.display.pixel(x, y, st7789.color565(0, 255, 0))
                
                if not tileGrid.bmp or len(tileGrid.bmp.pixels) == 0:
                    palette = tileGrid.pixel_shader
                    if palette:
                        # print(palette[0])
                        color16 = st7789.color565((palette[0] & 0xff0000) >> 16, (palette[0] & 0x00ff00) >> 8, (palette[0] & 0x0000ff))
                        self.display.fill_rect(tileGrid.x, tileGrid.y, tileGrid.bmp.width, tileGrid.bmp.height, color16)
                else:
                    x = tileGrid.x
                    y = tileGrid.y
                    bmp = tileGrid.bmp
                    palette = tileGrid.pixel_shader
                    pixels = bmp.pixels
                    width = bmp.width
                    
                    numGridW = tileGrid.numGridW
                    numGridH = tileGrid.numGridH
                    tileWidth = tileGrid.tileWidth
                    tileHeight = tileGrid.tileHeight
                    numTileW = bmp.width // tileGrid.tileWidth
                    numTileH = bmp.height // tileGrid.tileHeight
                    for jj in range(tileGrid.numGridH):
                        for ii in range(tileGrid.numGridW):
                            value = tileGrid[ii, jj] #which index of bmp section
                            valueH = value // numTileW
                            valueW = value - valueH * numTileW
                            for j in range(tileHeight):
                                jOffset = j + valueH * tileHeight
                                #buf = [0] * (tileWidth * 2)
                                for i in range(tileWidth):
                                    iOffset = i + valueW * tileWidth
                                    #index_color = 1 if ((pixels[(jOffset * width + iOffset) // 8]) & (1 << ((jOffset * width + iOffset) % 8))) != 0 else 0
                                    index_color = bmp[iOffset + jOffset * bmp.width] #bmp.width
                                    color = palette[index_color]
                                    if color & 0xff000000 != 0:
                                        color = color & 0xffffff
                                        color16 = st7789.color565((color & 0xff0000) >> 16, (color & 0x00ff00) >> 8, (color & 0x0000ff))
                                        self.display.pixel(x + i + ii * tileWidth, y + j + jj * tileHeight, color16);
                                        #buf[i * 2 + 0] = (color16 & 0xff00) >> 8
                                        #buf[i * 2 + 1] = color16 & 0xff
                                    else:
                                        pass #alpha color, skip
                                #self.display.blit_buffer(bytes(buf), x + ii * tileWidth, y + j + jj * tileHeight, tileWidth, 1)
                                
    
    def refresh(self, target_frames_per_second):
        pass

class FourWire:
    def __init__(self, spi, command, chip_select, reset) -> None:
        pass

def release_displays():
    pass
