import busio
import board
import digitalio
import displayio
import time
import os
import adafruit_imageload
from adafruit_st7789 import ST7789

button = digitalio.DigitalInOut(board.GP6)
button.direction = digitalio.Direction.INPUT
button.pull = digitalio.Pull.UP

displayio.release_displays()

spi = busio.SPI(board.GP2, board.GP3)
while not spi.try_lock():
    pass
spi.configure(baudrate=2400000, phase=1, polarity=1) # Configure SPI for 24MHz
spi.unlock()
tft_cs = board.GP5
tft_dc = board.GP1
tft_reset = board.GP0

display_bus = displayio.FourWire(spi, command=tft_dc, chip_select=tft_cs, reset=tft_reset)

display = ST7789(display_bus, width=240, height=240)
display.refresh(target_frames_per_second=10)

group = displayio.Group()
group.hidden=False

#################

ground_bmp, palette0 = adafruit_imageload.load("/img/ground512x12.bmp",
                                              bitmap=displayio.Bitmap,
                                              palette=displayio.Palette)

palette0.make_transparent(1)
palette0[0] = 0x808000
#palette0[1] = 0x404040
#palette0[0] = 0xff0000

if True:
    ground = displayio.TileGrid(ground_bmp, pixel_shader=palette0,
                                width=120,
                                height=1,
                                tile_width=2,
                                tile_height=12,
                                x=0,
                                y=192)
    for x in range(120):
        ground[x] = x
else:
    print("ground_bmp.width:", ground_bmp.width)
    ground = displayio.TileGrid(ground_bmp, pixel_shader=palette0,
                                width=1,
                                height=1,
                                tile_width=240,
                                tile_height=12,
                                default_tile=0)

group.append(ground)

#################

dinosaur_bmp, palette = adafruit_imageload.load("/img/dinosaur132x47.bmp",
                                                bitmap=displayio.Bitmap,
                                                palette=displayio.Palette)

palette.make_transparent(1)
palette[0] = 0x404040

# 44x47
dinosaur = displayio.TileGrid(dinosaur_bmp, pixel_shader=palette,
                              width=1,
                              height=1,
                              tile_width=44,
                              tile_height=47,
                              default_tile=2)

dinosaur.x = 8
dinosaur.y = 160

group.append(dinosaur)

#################

display.show(group)

#while True:
#    pass
