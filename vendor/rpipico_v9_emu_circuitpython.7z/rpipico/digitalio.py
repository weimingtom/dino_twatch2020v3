class DigitalIOObj:
    pass

class DigitalInOut:
    value: int = 1

class Direction:
    INPUT = 0

class Pull:
    UP = 0
