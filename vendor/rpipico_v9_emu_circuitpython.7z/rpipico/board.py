import machine

class BoardObj:
    pass

GP0 = machine.Pin(0)
GP1 = machine.Pin(1)
GP2 = machine.Pin(2)
GP3 = machine.Pin(3)
GP4 = machine.Pin(4)
GP5 = machine.Pin(5)
GP6 = machine.Pin(6)
GP7 = machine.Pin(7)
GP8 = machine.Pin(8)
GP9 = machine.Pin(9)
GP10 = machine.Pin(10)
GP11 = machine.Pin(11)
GP12 = machine.Pin(12)
GP13 = machine.Pin(13)
GP14 = machine.Pin(14)
GP15 = machine.Pin(15)
GP16 = machine.Pin(16)
GP17 = machine.Pin(17)
GP18 = machine.Pin(18)
GP19 = machine.Pin(19)
GP20 = machine.Pin(20)
